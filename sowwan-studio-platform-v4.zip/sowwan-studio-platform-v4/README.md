# Sowwan Studio Platform v4

Pure Node.js 100% demo/starter package.

## Included
- Landing page v4 with real Sowwan Studio logo assets
- Login/Register/Admin/Credits/Marketplace/AI/Sponsor/Chat
- Cloud Video Editor with Version 4 label
- Marketplace direction for video, audio, voice over, music, photo and design work
- AI Studio direction for text, AI Video and AI Voice connectors

## Run
```bash
cd sowwan-studio-platform-v4
cp .env.example .env
npm run check
npm start
```

Open: http://localhost:3000

## Seed admin
```bash
npm run seed:admin
```

Admin: admin@sowwanstudio.site
Password: ChangeMe123!

## Notes
This is an MVP/starter. For production, connect real database, payment, LINE, AI providers, HTTPS, backup and security hardening.
