# วิธีเชื่อม AI แบบภาษาคน

## หลักคิดก่อนเลือกโมเดล

ให้ตอบ 4 คำถามนี้ก่อน:

1. ต้องการทำอะไร: ข้อความ, ภาพ, วิดีโอ, เสียง หรือหลายอย่างรวมกัน
2. ต้องการเร็วหรือคม: เร็ว/ถูก ใช้โมเดลเล็ก, งานยาก/คุณภาพสูงใช้โมเดลใหญ่
3. ราคา API คุ้มกับเครดิตที่จะขายไหม
4. สิทธิ์ commercial / privacy / rate limit ชัดเจนไหม

## OpenAI สำหรับข้อความ / script / prompt

1. สมัคร/เข้า platform ของ OpenAI
2. สร้าง API key
3. ใส่ใน `.env`

```env
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-5.4-mini
```

4. Restart server
5. เข้า `/#ai` แล้วลองส่ง prompt

โค้ดเชื่อมอยู่ที่:

```text
lib/ai-provider.js
```

## Image / Video AI

ตอนนี้วางเป็น connector placeholder:

```env
IMAGE_AI_API_KEY=
VIDEO_AI_API_KEY=
```

ให้เลือก provider ที่มี API แล้วเขียน function เพิ่มใน `lib/ai-provider.js` เช่น:

```js
async function runVideoProvider(job) {
  // 1. ส่ง prompt ไป API ภายนอก
  // 2. รับ job id กลับมา
  // 3. poll จนเสร็จ
  // 4. คืน url วิดีโอหรือไฟล์ที่ระบบดาวน์โหลดมาเก็บ
}
```

## แนะนำการคิดเครดิต AI

ตัวอย่างเริ่มต้น:

- Script/caption: 1 credit
- Image: 2-5 credits
- Video 5 วินาที: 20-50 credits
- Video HD/long: คิดตามต้นทุนจริง + margin
