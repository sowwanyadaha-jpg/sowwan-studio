'use strict';

const crypto = require('crypto');

const email = process.argv[2];
const name = process.argv[3] || email;
const secret = process.env.SSO_SECRET || process.env.SESSION_SECRET;

if (!email || !secret) {
  console.error('Usage: SSO_SECRET=your-secret node scripts/sso-token-example.js user@example.com "User Name"');
  process.exit(1);
}

const payload = {
  email,
  name,
  exp: Math.floor(Date.now() / 1000) + 5 * 60
};

const payload64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
const sig = crypto.createHmac('sha256', secret).update(payload64).digest('base64url');
const token = `${payload64}.${sig}`;
console.log(token);
console.log(`https://sowwanstudio.site/api/auth/sso?token=${encodeURIComponent(token)}`);
