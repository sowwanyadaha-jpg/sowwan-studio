'use strict';
const path = require('path');
const fs = require('fs');
const ROOT = path.join(__dirname, '..');
function loadDotEnv() {
  const envPath = path.join(ROOT, '.env');
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim(); if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = trimmed.indexOf('='); if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim(); let value = trimmed.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[key] == null) process.env[key] = value;
  }
}
loadDotEnv();
const auth = require('../lib/auth');
const user = auth.ensureAdminUser({});
console.log('Admin ready:', user.email);
console.log('Password:', process.env.ADMIN_PASSWORD || 'ChangeMe123!');
console.log('Please change this password before production.');
