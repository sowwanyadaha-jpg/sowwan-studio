# Deploy ไปยัง sowwanstudio.site

## แนวทางแนะนำ

ใช้ Node.js app นี้หลัง Nginx reverse proxy

```text
https://sowwanstudio.site  -> Nginx -> localhost:3000
```

## ตัวอย่าง Nginx

```nginx
server {
  server_name sowwanstudio.site www.sowwanstudio.site;

  client_max_body_size 4096M;

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

## Production .env

```env
PORT=3000
APP_ORIGIN=https://sowwanstudio.site
COOKIE_DOMAIN=.sowwanstudio.site
COOKIE_SECURE=true
COOKIE_SAMESITE=Lax
SESSION_SECRET=สุ่มยาวมากๆ
SSO_SECRET=สุ่มยาวมากๆ
```

## คำสั่งรันแบบง่าย

```bash
npm start
```

ถ้าใช้ PM2:

```bash
pm2 start server.js --name sowwan-studio
pm2 save
```

## Folder ที่ต้อง backup

```text
data/
projects/
uploads/
renders/
```
